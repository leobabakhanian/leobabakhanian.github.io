<?php include('database.php'); // Call database file to pass user inputs into?>
<!DOCTYPE html>
<html>
    <head>
        <title>Registration Success</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body class="wrapper">
        <div class="header">
            <h2>Registered!</h2>
        </div>
        <div class="regSuccess">
            <p><a href="login.php">Log In</a></p>
        </div>
    </body>
</html>