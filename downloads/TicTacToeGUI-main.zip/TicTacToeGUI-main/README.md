# TicTacToeGUI
A cool little Tic Tac Toe game I made with GUI using JavaFX. The game has two modes: vs Player and vs CPU.
